.. raw:: latex

	\clearpage




.. only:: html

  Abbreviations
  =============

..

.. raw:: latex
     
   \chapter*{Abbreviations}
   \addcontentsline{toc}{chapter}{Abbreviations}
   
..


   **CAD**: Computer aided design

   **CV**: Check valve

   **DDA**: Demand driven analysis

   **EPA**: Environmental Protection Agency

   **EPS**: Extended period simulation

   **FCV**: Flow control valve

   **FIFO**: First in first out

   **GGA**: Global gradient algorithm

   **GIS**: Geographic information system

   **GPV**: General purpose valve

   **LIFO**: Last in first out 

   **PBV**: Pressure breaker valve

   **PDA**: Pressure driven analysis

   **PDD**: Pressure driven demand
   
   **PRV**: Pressure reducing valve

   **PSV**: Pressure sustaining valve 

   **SI**: International System of Units

   **TCV**: Throttle control valve

   **THM**: Trihalomethanes

   **US**: United States







